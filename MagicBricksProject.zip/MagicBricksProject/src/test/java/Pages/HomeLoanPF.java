package Pages;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

public class HomeLoanPF {
	
	WebDriver driver;
	Actions actions;
	JavascriptExecutor js;
	
	public HomeLoanPF(WebDriver driver, Actions actions, JavascriptExecutor js) {
		this.driver = driver;
		this.actions = new Actions(driver);
		this.js = (JavascriptExecutor) driver;
	}
//	-----------------------------------------------------Locators------------------------------------------------
	@FindBy(xpath="//a[text()='Login']")
	WebElement mainMenu;
	
	@FindBy(xpath="//a[@class='mb-login__drop-cta']")
	WebElement subMenu;
	
	@FindBy(id="emailOrMobile")
	WebElement mailOrMob;
	
	@FindBy(tagName="button")
	WebElement next;
	
	@FindBy(id="password")
	WebElement password;
	
	@FindBy(id="btnLogin")
	WebElement loginBtn;
	
	@FindBy(xpath="//li[@class='js-menu-container']/child::a[text()='Home Loans']")
	WebElement homeLoan;
	
	@FindBy(css="a[href='https://www.magicbricks.com/homeloan/prepayment-calculator']")
	WebElement homeLoanPrepay;
	
	@FindBy(id="lalpc")
	WebElement lAmt;
	
	@FindBy(xpath="//input[@id='ltlpc']")
	WebElement tenure;
	
	@FindBy(id="rplc")
	WebElement roi;
	
	@FindBy(xpath="//div[@class='formField']/child::input")
	WebElement installmentPaid;
	
	@FindBy(id="palpc")
	WebElement prepayAmt;
	
	@FindBy(className = "home-loan__action--btn btn-red large")
	WebElement calcBtn;

//	--------------------------------------------------------Methods---------------------------------------------------------------
	//method to move to login tab
	public void toLoginPage() {
		
		actions.moveToElement(mainMenu);
		actions.moveToElement(subMenu); 
		actions.click().build().perform();
		String mainWindow  = driver.getWindowHandle();
		Set<String> allwindows = driver.getWindowHandles();
		Iterator<String> itr = allwindows.iterator();
		while(itr.hasNext())
		{
			String childwindow=itr.next();
			if(!mainWindow.equalsIgnoreCase(childwindow))
			{
				driver.switchTo().window(childwindow);
			}
		}
	}
	
//	entering credentials
	public void enterCredentials(String mail, String pass) {
		mailOrMob.sendKeys(mail);
		next.click();
		password.sendKeys(pass);
		loginBtn.click();
	}
	
//	move to homeloan
	public void movesToHomeLoan() {
		actions.moveToElement(homeLoan);
		homeLoanPrepay.click();
	}

//	sending keys to the fields using scenario outline
	public void enterDetails(String string, String string2, String string3, String string4, String string5) {
		lAmt.sendKeys(string);
		tenure.sendKeys(string2);
		roi.sendKeys(string3);
		installmentPaid.sendKeys(string4);
		prepayAmt.sendKeys(string5);
	}
	
//	clicking login button
	public void clickCalc() {
//        js.executeScript("arguments[0].click();", calcBtn);
		calcBtn.click();
	}

}
