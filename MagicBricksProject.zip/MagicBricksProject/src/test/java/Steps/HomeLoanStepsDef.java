package Steps;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.demo.project.MagicBricks.Setup;

import Pages.HomeLoanPF;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomeLoanStepsDef {

	WebDriver driver;
	HomeLoanPF hlpf;

	@Given("User Is On Landing Page")
	public void user_is_on_landing_page() {		
			Setup s = new Setup("edge");
			driver = s.initDriver();
			driver.navigate().to("https://www.magicbricks.com/");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		// Initialize the PageFactory
		hlpf = PageFactory.initElements(driver, HomeLoanPF.class);
	}
	
	@When("User Able To Go On Login Page")
	public void user_able_to_go_on_login_page() {
		hlpf.toLoginPage();		
	}
	
	@When("User Is Able To Enter Mobile No or Email ID")
	public void user_is_able_to_enter_mobile_no_or_email_id() {
	    hlpf.enterCredentials("magicsbricks456@gmail.com", "m@g!c12345");
	}
	
	@Then("User Is On Next Page")
	public void user_is_on_next_page() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	@Given("User must be logged in")
	public void user_must_be_logged_in() {
		
	}
	@When("User entered the homepage")
	public void user_entered_the_homepage() {
	    
	}
	
	@When("moves to home loan repayment page")
	public void moves_to_home_loan_repayment_page() {
	    hlpf.movesToHomeLoan();
	}
	
	@When("User must enter the {string}, {string}, {string}, {string}, {string}")
	public void user_must_enter_the(String string, String string2, String string3, String string4, String string5) {
	    hlpf.enterDetails(string, string2, string3, string4, string5);
	    hlpf.clickCalc();
	}
	
	@When("After entering all the details User need to click the calculate button")
	public void after_entering_all_the_details_user_need_to_click_the_calculate_button() {
	    
	}
	
	@Then("Check the amount to be saved")
	public void check_the_amount_to_be_saved() {
	    
	}




}
